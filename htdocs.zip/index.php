<?php
session_name("jwmf");
session_start();

// Retrieve 'title' from POST or use default value
$title = isset($_POST['title']) ? htmlentities($_POST['title']) : "INTERNET ID CARD";

// Get 'name' and 'externalImage' dynamically from the URL
$name = isset($_GET['name']) ? htmlentities($_GET['name']) : "Hasan";
$externalImageURL = isset($_GET['externalImage']) ? $_GET['externalImage'] : "https://files.catbox.moe/42v943.jpg";

$random = "$" . rand(1000, 100000);

// Load external image from the URL
$externalImage = imagecreatefromjpeg($externalImageURL); 
$originalWidth = imagesx($externalImage);
$originalHeight = imagesy($externalImage);
$newWidth = $originalWidth * 0.84; // 84% width
$newHeight = $originalHeight * 0.63; // 42% height

$bgpic = imagecreatefromjpeg("hasan.jpg"); // Ensure nid.jpg is the correct background file
$textcolor = imagecolorallocate($bgpic, 255, 255, 255);
$infcolor = imagecolorallocate($bgpic, 63, 46, 38);
$stscolor = imagecolorallocate($bgpic, 0x00, 0x55, 0x00);
$ttscolor = imagecolorallocate($bgpic, 255, 0, 0);
$posX = 43; // Horizontal position (distance from left)
$posY = 190; // Vertical position (distance from top)

// Font paths
$font = __DIR__ . "/fonts/hasan.ttf";
$font2 = __DIR__ . "/fonts/hasan2.otf";
$font3 = __DIR__ . "/fonts/hasan3.ttf";

// Add text to the image
imagettftext($bgpic, 80, 0, 140, 765, $infcolor, $font2, $name);
imagettftext($bgpic, 40, 0, 200, 830, $infcolor, $font3, $random);
imagecopyresized($bgpic, $externalImage, $posX, $posY, 0, 0, $newWidth, $newHeight, $originalWidth, $originalHeight);

// Check if an image file is uploaded
$avl = $_FILES['file']['tmp_name'];
if (trim($avl != "")) {
    $imgi = getimagesize($avl);
    if ($imgi[0] > 0) {
        if ($imgi[2] == IMAGETYPE_JPEG) {
            $av = imagecreatefromjpeg($avl);
        } elseif ($imgi[2] == IMAGETYPE_PNG) {
            $av = imagecreatefrompng($avl);
        } elseif ($imgi[2] == IMAGETYPE_GIF) {
            $av = imagecreatefromgif($avl);
        }

        // Resize and copy user-uploaded image to background
        if (isset($av)) {
            imagecopyresized($bgpic, $av, 39, 152, 0, 0, 100, 120, $imgi[0], $imgi[1]);
            imagedestroy($av);
        }
    }
}

// Send the appropriate headers for the image type
header('Content-Type: image/jpeg');

// Output the image directly to the browser
imagejpeg($bgpic);
imagedestroy($bgpic);
?>